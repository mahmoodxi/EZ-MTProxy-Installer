var globalVars = {
	"templateDir" : "",
	"contact_form_required_fields_label_ajax" : "This is a required field.",
	"contact_form_warning" : "Please verify fields and try again.",
	"contact_form_email_warning" : "Please enter a valid e-mail address and try again.",
	"contact_form_error" : "There was an error sending your email. Please try again later.",
	"contact_form_success_message" : "Thanks, we got your mail and will get back to you in 24h!"
};